<?php
namespace App\Enum;
enum Unit:string
{
    case PCS = "g";  //peice counting mode.
    case UOV = "ml";  //unit of valume in millilitre.
}
?>